import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'cool-cool-tools-lib',
  template: `
    <p>
      cool-tools-lib works!
    </p>
  `,
  styles: []
})
export class CoolToolsLibComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
