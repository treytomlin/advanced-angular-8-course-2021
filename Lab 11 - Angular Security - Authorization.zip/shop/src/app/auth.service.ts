import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { tap } from 'rxjs/operators';
import * as decode from 'jwt-decode';
import { CanActivate, Router } from '@angular/router';

@Injectable({
  providedIn: 'root'
})
export class AuthService implements CanActivate {

  userProfile:UserProfile

  jwtToken:string

  constructor(private http:HttpClient, private router:Router) { }

  login(credentials:LoginRequest) : Observable<LoginResponse> {
    return this.http.post<LoginResponse>("/api/auth/login", credentials)
      .pipe(tap(response => {
        this.jwtToken = response.token
        this.userProfile = decode<UserProfile>(this.jwtToken)
      }))
  }

  logout() {
    this.jwtToken = undefined
  }

  isLoggedIn() : boolean {
    return this.jwtToken !== undefined && 
        this.jwtToken != null
  }

  canActivate(): boolean {
    if (!this.isLoggedIn()) {
      this.router.navigate(["/login"])
  
      return false
    } else {
      return true
    }
  }
}

export class LoginRequest {
  userId:string
  password:string
}

export class LoginResponse {
  token:string
}

export class UserProfile {
  email:string
  name:string
}