import { GridLayoutDirective } from './grid-layout.directive';

describe('GridLayoutDirective', () => {
  it('should create an instance', () => {
    const directive = new GridLayoutDirective();
    expect(directive).toBeTruthy();
  });
});
