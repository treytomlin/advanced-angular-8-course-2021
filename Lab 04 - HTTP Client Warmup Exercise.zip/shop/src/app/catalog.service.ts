import { Injectable } from '@angular/core';
import { Product } from './product';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import { tap } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})

export class CatalogService {
  
  cachedCatalog?:Product[]
  
  constructor(private http:HttpClient) {}

  getProducts() : Observable<Product[]> {
    if (this.cachedCatalog) {
      console.log("Cache hit")
      
      return of(this.cachedCatalog)      
    }

    return this.http.get<Product[]>("/api/catalog")
    .pipe(tap(catalog => this.cachedCatalog = catalog))
  }
  
  search(query:string) : Observable<Product[]> {
    return this.http.get<Product[]>("/api/catalog/search/" + 
      encodeURI(query))
  }
}
