import { Directive, ElementRef, Input, HostBinding } from '@angular/core';

@Directive({
  selector: '[appGridLayout]'
})
export class GridLayoutDirective {

  constructor(private host: ElementRef) { }

  @Input()
  @HostBinding("style.gridRowGap")
  @HostBinding("style.gridColumnGap")
  gap:string = "0px"

  @Input("appGridLayout")
  itemsPerRow:number = 1

  ngOnInit() {
    this.host.nativeElement.style.display = "grid"
  }
  
  ngOnChanges() {
    let cols = ""
  
    for (let i = 0; i < this.itemsPerRow; ++i) {
      cols += "auto "
    }
  
    this.host.nativeElement.style.gridTemplateColumns = cols
  }

}
